({
	createLinkTitle: "Link Properties",
	insertImageTitle: "Image Properties",
	url: "URL:",
	text: "Description:",
	target: "Target:",
	set: "Set",
	currentWindow: "Current Window",
	parentWindow: "Parent Window",
	topWindow: "Topmost Window",
	newWindow: "New Window"
})
