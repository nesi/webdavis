({
	buttonOk: "אישור",
	buttonCancel: "ביטול",
	buttonSave: "שמירה",
	itemClose: "סגירה"
})
